#include <stdio.h>
#include <string.h>
#include <windows.h>

void fun2()
{
	MessageBoxA(NULL, "YouWin", "PASS", MB_OK);
}

int fun(char *str)
{
	char buffer[4];
	strcpy(buffer, str);
	return 0;
}

int main()
{
	MessageBoxA(NULL, "test", "ok", MB_OK);
	char buff[] = "000011112222333344445555";
	DWORD *pEIP = (DWORD*)&buff[8];
	*pEIP = (DWORD)fun2;
	fun(buff);
	printf("%s\n", buff);

	return 0;
}
