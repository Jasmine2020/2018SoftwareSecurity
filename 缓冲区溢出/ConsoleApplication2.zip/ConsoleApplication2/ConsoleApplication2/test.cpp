//#include <windows.h>
//#include <string.h>
//#include <stdio.h>
//int fun(char *name)
//{
//	char buf[4];
//	strcpy(buf, name);
//	return 0;
//}
//int main()
//{
//	MessageBoxA(NULL, "test", "ok", MB_OK);
//	char buff[] = "123aaaaaaaaa";
//	fun(buff);
//	printf("%s\n", buff);
//	
//	return 0;
//}
//
//
